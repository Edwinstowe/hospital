const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const DAY=864e5,now=Date.now(),iso=d=>new Date(d).toISOString().slice(0,10),today=iso(now);
const ago=t=>{const h=Math.round((Date.now()-t)/36e5);return h<1?'just now':h<48?h+'h ago':Math.round(h/24)+'d ago'};
const money=n=>'KES '+Number(n).toLocaleString('en-US');
const tag=(t,c)=>`<span class="tag ${c||String(t).replace(/\W/g,'')}">${esc(t)}</span>`;
const card=h=>`<div class="card">${h}</div>`;
const btn=(t,f,c)=>`<button class="btn sm ${c||''}" onclick="${f}">${t}</button>`;
const empty=t=>`<div class="empty">${t}</div>`;
const stat=(n,l,c)=>`<div class="card stat"><b class="${c||''}">${n}</b>${l}</div>`;
const bars=rows=>{const mx=Math.max(1,...rows.map(r=>r[1]));return rows.map(([l,v])=>`<div class="bar"><span>${esc(l)}</span><i style="width:${Math.max(3,v/mx*60)}%"></i><b>${v}</b></div>`).join('')};
const toast=m=>{const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(toast.h);toast.h=setTimeout(()=>t.style.display='none',2800)};

const DOCS=['Dr. Wanjiru Kamau (General)','Dr. Otieno Mwangi (Physician)','Dr. Amina Yusuf (Paediatrics)'];
const LABS=[{t:'Malaria test',p:300},{t:'Full blood count',p:600},{t:'Urinalysis',p:250},{t:'Blood sugar',p:200}];
const KEY='hm',ROLES=['Patient','Receptionist','Doctor','Lab Technician','Pharmacist','Cashier'],PROFROLE='Doctor',PROFLABEL='Your doctor profile',PROF=DOCS,FEE=500;
function seed(){return{visits:[
{id:1,pat:'Grace Njeri',phone:'0712345678',age:34,doc:DOCS[0],stage:'Closed',dx:'Malaria',labs:[{t:'Malaria test',p:300,res:'Positive'}],rx:[{d:'Artemether/Lumefantrine',q:1,p:150,done:true}],paid:true,pay:'M-Pesa',at:now-2*DAY},
{id:2,pat:'Peter Kamau',phone:'0700111222',age:51,doc:DOCS[0],stage:'Waiting',dx:'',labs:[],rx:[],paid:false,pay:'',at:now-36e5}],
drugs:[{d:'Paracetamol 500mg',stock:200,p:5},{d:'Amoxicillin 500mg',stock:120,p:20},{d:'ORS sachet',stock:60,p:30},{d:'Artemether/Lumefantrine',stock:80,p:150},{d:'Metformin 500mg',stock:18,p:10}],notes:[],seq:3}}
const tabs=()=>({Patient:[['home','My visits']],Receptionist:[['home','Register visit']],Doctor:[['home','My patients'],['hist','History']],'Lab Technician':[['home','Lab requests']],Pharmacist:[['home','Prescriptions'],['stock','Stock']],Cashier:[['home','Billing']],Admin:[['home','Overview'],['visits','All visits'],['stock','Stock']]}[role]||[]).concat([['alerts','Alerts']]);
const V=id=>S.visits.find(v=>v.id===id);
const bill=v=>FEE+v.labs.reduce((t,l)=>t+l.p,0)+v.rx.filter(r=>r.done).reduce((t,r)=>t+r.q*r.p,0);
const pendingLab=v=>v.labs.some(l=>!l.res);
function vsum(v){return `<div class="row"><b>#${v.id} ${esc(v.pat)} (${v.age})</b>${tag(v.stage)}</div><div class="sub">${esc(v.doc)} · ${ago(v.at)} · ${esc(v.phone)}${v.dx?'<br><b>Diagnosis:</b> '+esc(v.dx):''}${v.labs.length?'<br><b>Labs:</b> '+v.labs.map(l=>esc(l.t)+': '+(l.res?esc(l.res):'pending')).join('; '):''}${v.rx.length?'<br><b>Prescription:</b> '+v.rx.map(r=>esc(r.d)+' x'+r.q+(r.done?' (dispensed)':'')).join('; '):''}</div>`}
function regVisit(){const n=$('rn').value.trim(),ph=$('rp').value.trim(),ag=+$('ra').value;if(!n||!ph||!(ag>0))return toast('Enter the name, phone and age');
 const v={id:S.seq++,pat:n,phone:ph,age:ag,doc:$('rd').value,stage:'Waiting',dx:'',labs:[],rx:[],paid:false,pay:'',at:Date.now()};S.visits.unshift(v);
 notify(`New patient waiting: ${n} (${ag}).`,v.doc);notify(`You are registered to see ${v.doc}. Visit number ${v.id}.`,n);save();toast('Visit registered');draw()}
const startC=id=>{V(id).stage='Consulting';notify('The doctor is ready to see you.',V(id).pat);save();draw()};
function orderLab(id){const t=$('lt'+id).value,l=LABS.find(x=>x.t===t),v=V(id);v.labs.push({t,p:l.p,res:''});notify(`Lab test ordered for ${v.pat}: ${t}`,'role:Lab Technician');save();draw()}
function addRx(id){const d=$('rd'+id).value,q=+$('rq'+id).value,v=V(id),dr=S.drugs.find(x=>x.d===d);if(!(q>0))return toast('Enter the quantity');v.rx.push({d,q,p:dr.p,done:false});save();draw()}
function finishC(id){const v=V(id),dx=$('dx'+id).value.trim();if(!dx)return toast('Enter the diagnosis first');if(pendingLab(v))return toast('Wait for the lab results before finishing');
 v.dx=dx;v.stage=v.rx.length?'Pharmacy':'Billing';notify(v.rx.length?`Prescription ready for ${v.pat}.`:`Bill ready for ${v.pat}.`,v.rx.length?'role:Pharmacist':'role:Cashier');notify(`Consultation complete. Diagnosis: ${dx}. Please go to the ${v.rx.length?'pharmacy':'cashier'}.`,v.pat);save();toast('Consultation finished');draw()}
function labSave(id,i){const v=V(id),r=$('res'+id+'_'+i).value.trim();if(!r)return toast('Enter the result');v.labs[i].res=r;notify(`Lab result for ${v.pat}: ${v.labs[i].t} = ${r}`,v.doc);save();toast('Result saved');draw()}
function dispense(id){const v=V(id),short=v.rx.filter(r=>!r.done&&S.drugs.find(x=>x.d===r.d).stock<r.q);if(short.length)return toast('Not enough stock: '+short.map(r=>r.d).join(', '));
 v.rx.forEach(r=>{if(r.done)return;const d=S.drugs.find(x=>x.d===r.d);d.stock-=r.q;r.done=true;if(d.stock<20)notify(`Low stock: ${d.d} (${d.stock} left).`,'Admin')});
 v.stage='Billing';notify(`Medicines dispensed. Please pay at the cashier.`,v.pat);notify(`Bill ready for ${v.pat}: ${money(bill(v))}.`,'role:Cashier');save();toast('Dispensed');draw()}
function pay(id){const v=V(id);v.paid=true;v.pay=$('pm'+id).value;v.stage='Closed';notify(`Payment of ${money(bill(v))} received (${v.pay}). Thank you. Get well soon.`,v.pat);save();toast('Payment recorded');draw()}
function addStock(i){const q=+$('st'+i).value;if(!(q>0))return toast('Enter the quantity');S.drugs[i].stock+=q;save();toast('Stock updated');draw()}
const list=(l,f,e)=>l.length?l.map(v=>card(vsum(v)+f(v))).join(''):empty(e);
function doctorCtl(v){if(v.stage==='Waiting')return `<div style="margin-top:8px">${btn('Start consultation','startC('+v.id+')')}</div>`;if(v.stage!=='Consulting')return '';
 return `<label>Diagnosis</label><input id="dx${v.id}" value="${esc(v.dx)}"><div class="grid"><div><label>Order a lab test</label><select id="lt${v.id}">${LABS.map(l=>`<option>${l.t}</option>`).join('')}</select>${btn('Order test','orderLab('+v.id+')','ghost')}</div><div><label>Prescribe</label><select id="rd${v.id}">${S.drugs.map(d=>`<option>${esc(d.d)}</option>`).join('')}</select><input id="rq${v.id}" type="number" min="1" value="1" style="margin-top:4px">${btn('Add drug','addRx('+v.id+')','ghost')}</div></div><div style="margin-top:8px">${btn('Finish consultation','finishC('+v.id+')')}</div>`}
function overview(){const t=S.visits.filter(v=>iso(v.at)===today),rev=S.visits.filter(v=>v.paid&&iso(v.at)===today).reduce((a,v)=>a+bill(v),0);
 return `<div class="grid four">${stat(t.length,'visits today')}${stat(S.visits.filter(v=>v.stage!=='Closed').length,'in progress','info')}${stat(money(rev),'revenue today','ok')}${stat(S.drugs.filter(d=>d.stock<20).length,'low-stock drugs','bad')}</div>
 <div class="card"><b>Visits by stage</b>${bars(['Waiting','Consulting','Pharmacy','Billing','Closed'].map(s=>[s,S.visits.filter(v=>v.stage===s).length]))}</div><div class="card"><b>Visits by doctor</b>${bars(DOCS.map(d=>[d.split('(')[0].trim(),S.visits.filter(v=>v.doc===d).length]))}</div>`}
function stockView(w){return S.drugs.map((d,i)=>card(`<div class="row"><b>${esc(d.d)}</b>${tag(d.stock<20?'Low':'OK',d.stock<20?'bad':'ok')}</div><div class="sub">${d.stock} in stock · ${money(d.p)} each</div>${w?`<div style="display:flex;gap:8px;margin-top:8px"><input id="st${i}" type="number" min="1" placeholder="Add quantity" style="width:140px">${btn('Add stock','addStock('+i+')')}</div>`:''}`)).join('')}
function view(){
 if(role==='Patient')return '<h2>My visits</h2>'+list(S.visits.filter(v=>v.pat===me),v=>`<div class="sub" style="margin-top:6px">${v.stage==='Closed'?'Paid '+money(bill(v))+' by '+esc(v.pay):'Bill so far: '+money(bill(v))}</div>`,'No visits yet. The receptionist registers each visit.');
 if(role==='Receptionist')return card(`<b>Register a visit</b><label>Patient name</label><input id="rn"><label>Phone</label><input id="rp" type="tel"><label>Age</label><input id="ra" type="number" min="0"><label>Doctor</label><select id="rd">${DOCS.map(d=>`<option>${esc(d)}</option>`).join('')}</select><div style="margin-top:12px">${btn('Register visit','regVisit()')}</div>`)+'<h2>Today</h2>'+list(S.visits.filter(v=>iso(v.at)===today),()=>'','No visits today.');
 if(role==='Doctor')return tab==='hist'?'<h2>Past patients</h2>'+list(S.visits.filter(v=>v.doc===prof&&!['Waiting','Consulting'].includes(v.stage)),()=>'','None yet.'):`<div class="sub" style="margin-top:8px">${esc(prof)}</div><h2>Waiting and in consultation</h2>`+list(S.visits.filter(v=>v.doc===prof&&['Waiting','Consulting'].includes(v.stage)),doctorCtl,'No patients waiting.');
 if(role==='Lab Technician')return '<h2>Lab requests</h2>'+list(S.visits.filter(v=>pendingLab(v)),v=>v.labs.map((l,i)=>l.res?'':`<div style="display:flex;gap:8px;margin-top:8px;align-items:center"><span class="sub" style="width:120px">${esc(l.t)}</span><input id="res${v.id}_${i}" placeholder="Result">${btn('Save','labSave('+v.id+','+i+')')}</div>`).join(''),'No pending tests.');
 if(role==='Pharmacist')return tab==='stock'?stockView(true):'<h2>Prescriptions to dispense</h2>'+list(S.visits.filter(v=>v.stage==='Pharmacy'),v=>`<div style="margin-top:8px">${btn('Dispense all','dispense('+v.id+')')}</div>`,'No prescriptions waiting.');
 if(role==='Cashier')return '<h2>Bills to collect</h2>'+list(S.visits.filter(v=>v.stage==='Billing'),v=>`<div style="margin-top:6px">Total: <b>${money(bill(v))}</b> (consultation ${money(FEE)}, labs ${money(v.labs.reduce((t,l)=>t+l.p,0))}, medicines ${money(v.rx.reduce((t,r)=>t+r.q*r.p,0))})</div><div style="display:flex;gap:8px;margin-top:8px"><select id="pm${v.id}" style="width:130px"><option>M-Pesa</option><option>Cash</option><option>Insurance</option></select>${btn('Record payment','pay('+v.id+')')}</div>`,'No bills waiting.');
 if(tab==='visits')return '<h2>All visits</h2>'+list(S.visits,()=>'','None.');if(tab==='stock')return stockView(true);return overview()}

let S;try{S=JSON.parse(localStorage.getItem(KEY+'_d'))}catch(e){}
if(!S)S=seed();
const save=()=>{try{localStorage.setItem(KEY+'_d',JSON.stringify(S))}catch(e){}};
let tab='home',role='',me='',prof='',mode='login',aerr='';
const key=()=>role==='Admin'?'Admin':(role===PROFROLE&&prof?prof:me);
const notify=(m,who)=>{S.notes.unshift({m,who,at:Date.now(),read:false})};
const mine=()=>S.notes.filter(n=>n.who===key()||n.who==='role:'+role);
const getU=()=>{try{return JSON.parse(localStorage.getItem(KEY+'_users'))||[]}catch(e){return[]}};
const putU=u=>{try{localStorage.setItem(KEY+'_users',JSON.stringify(u))}catch(e){}};
const cur=()=>{try{const e=localStorage.getItem(KEY+'_sess');return getU().find(u=>u.email===e)||null}catch(e){return null}};
async function hash(p,s){const enc=new TextEncoder(),k=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);
 const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(s),iterations:100000,hash:'SHA-256'},k,256);
 return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}
const bad=m=>{aerr=m;const e=$('xerr');if(e)e.textContent=m};
const xrole=()=>{if(PROFROLE)$('xpf').style.display=$('xr').value===PROFROLE?'block':'none'};
function authView(){const reg=mode==='reg';
 return `<div class="card auth"><b>${reg?'Create your account':'Log in'}</b>
 ${reg?`<label>Full name</label><input id="xn" autocomplete="name">`:''}
 <label>Email</label><input id="xe" type="email" autocomplete="email">
 <label>Password</label><input id="xp" type="password" autocomplete="${reg?'new-password':'current-password'}">
 ${reg?`<label>Confirm password</label><input id="xp2" type="password" autocomplete="new-password">
 <label>Account type</label><select id="xr" onchange="xrole()">${ROLES.map(r=>`<option>${r}</option>`).join('')}</select>
 ${PROFROLE?`<div id="xpf" style="display:${ROLES[0]===PROFROLE?'block':'none'}"><label>${PROFLABEL}</label><select id="xl">${PROF.map(p=>`<option>${esc(p)}</option>`).join('')}</select></div>`:''}
 <div class="sub" style="margin-top:8px">The first account created becomes the administrator.</div>`:''}
 <div class="err" id="xerr">${esc(aerr)}</div>
 <div style="margin-top:12px"><button class="btn" onclick="${reg?'doReg()':'doLogin()'}">${reg?'Register':'Log in'}</button></div>
 <div class="sub" style="margin-top:12px">${reg?'Already registered?':'New here?'} <button class="link" onclick="mode='${reg?'login':'reg'}';aerr='';draw()">${reg?'Log in':'Create an account'}</button></div></div>`}
async function doReg(){const n=$('xn').value.trim(),e=$('xe').value.trim().toLowerCase(),p=$('xp').value;
 if(!n)return bad('Enter your full name.');
 if(!/^\S+@\S+\.\S+$/.test(e))return bad('Enter a valid email address.');
 if(p.length<8)return bad('Password must be at least 8 characters.');
 if(p!==$('xp2').value)return bad('Passwords do not match.');
 const us=getU();if(us.some(u=>u.email===e))return bad('That email is already registered. Log in instead.');
 const salt=Array.from(crypto.getRandomValues(new Uint8Array(8))).join('-');
 const r=us.length?$('xr').value:'Admin',pf=(r===PROFROLE)?$('xl').value:'';
 us.push({email:e,name:n,role:r,prof:pf,salt,h:await hash(p,salt)});putU(us);
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
async function doLogin(){const e=$('xe').value.trim().toLowerCase(),u=getU().find(x=>x.email===e);
 if(!u||u.h!==await hash($('xp').value,u.salt))return bad('Email or password is incorrect.');
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
function start(){const u=cur();if(!u)return;role=u.role;me=u.name;prof=u.prof||'';tab='home';aerr='';draw()}
function logout(){try{localStorage.removeItem(KEY+'_sess')}catch(e){}mode='login';aerr='';draw()}
function drawNav(){const u=mine().filter(n=>!n.read).length;
 $('nav').innerHTML=tabs().map(([k,l])=>`<button class="${tab===k?'on':''}" onclick="go('${k}')">${l}${k==='alerts'&&u?`<span class="dot">${u}</span>`:''}</button>`).join('')}
const go=k=>{tab=k;draw()};
function alertsView(){const n=mine();n.forEach(x=>x.read=true);save();return n.length?n.map(x=>card(esc(x.m)+`<div class="sub">${ago(x.at)}</div>`)).join(''):empty('No alerts yet.')}
function draw(){const u=cur();$('who').innerHTML=u?`<span>${esc(u.name)} · ${role}</span><button class="btn sm ghost" onclick="logout()">Log out</button>`:'';
 if(!u){$('nav').innerHTML='';$('main').innerHTML=authView();return}
 drawNav();$('main').innerHTML=tab==='alerts'?alertsView():view()}
start();draw();
