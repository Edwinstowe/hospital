# MediCore: Hospital Management System

## Files
- `index.html`  page structure (open this file in a browser)
- `style.css`   all styling (colours are CSS variables at the top)
- `script.js`   all logic: sample data, registration and login, role screens, notifications

## Run
Double-click `index.html`, or open the folder in VS Code and use the Live Server extension ("Go Live").

## Notes
- The first account you register becomes the Administrator. Other accounts choose a role at registration.
- Data is saved in the browser (localStorage). To reset, clear the site data in the browser developer tools.
- In `script.js`, `function seed()` holds the sample data and `const KEY=` sets the storage name.
- Payments use M-Pesa codes that are recorded and confirmed by hand. There is no live M-Pesa connection.
